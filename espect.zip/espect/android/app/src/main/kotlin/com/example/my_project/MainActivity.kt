package com.rdbfutura.espect

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
